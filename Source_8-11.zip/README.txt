Included in this archive are assets and source code for the iOS and Android
sections of the Devslopes "Beginner API development in Node, Express, ES6
and MongoDB" course.

foodtruck-api - source code for the updated api, including some minor
  changes that were made at the beginning of the iOS Section.

Assets - Graphics assets used in creation of the iOS app.

api-client - Source code for the iOS client application.

We hope you have enjoyed the course and look forward to see where you take
this in your own development!

Team Devslopes
