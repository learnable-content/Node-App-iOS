export default {
  "port": 3005,
  "bodyLimit": "100kb"
}
